#include<iostream>
#include "HashNode.h"

HashNode::HashNode(){
}

HashNode::HashNode(string k, string v){
}

string HashNode::getKey() {
}

void HashNode::setValue(string v){
}

string HashNode::getValue() {
}

ostream& operator<<(ostream &output, const HashNode &hn) {
}
